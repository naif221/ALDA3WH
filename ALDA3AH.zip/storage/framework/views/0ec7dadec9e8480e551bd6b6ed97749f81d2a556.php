<?php echo $__env->make('cpac/style/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('cpac/style/slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">المكتبة</h1>

                    
                    <a  class="btn btn-primary"   href="new-languge" >
                   <i class="fa fa-pencil-square-o" aria-hidden="true"></i> اضافة لغة جديدة </a>


<br>

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            لغات الكتب
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>الرقم</th>
                                            <th> اللغة</th>
                                            <th>عدد الكتب</th>
                                          <!--  <th>تعديل/حذف</th>-->
                                            </tr>
                                    </thead>
                                    <tbody>
                                    
<?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="odd gradeX">
                                        	<td><?php echo e($lang->id); ?></td>
                                        	<td><?php echo e($lang->language); ?></td>
                                            <td><?php echo e(count($lang->book)); ?></td>
                                       
                                       
                                           <!-- <td><center>
                                            <a href="" onclick="deleted()" ><i class="fa fa-trash-o fa-2x" aria-hidden="true"></i></a>
                                            </center>
                                        </td>-->
               
                                        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>









                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>



<?php echo $__env->make('cpac/style/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>