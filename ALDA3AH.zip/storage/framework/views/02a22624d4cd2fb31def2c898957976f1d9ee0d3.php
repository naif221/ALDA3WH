<?php echo $__env->make('cpac/style/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('cpac/style/slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	

<div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
               
                    <h3 class="page-header">الرئيسية</h3>
                   
                <h4> مرحبا بك</h4>

                
                   <br>
                   <hr>
                   
                   <a href="profile" > <i class="fa fa-user-circle fa-5x"></i> <br>الملف الشخصي</a>
                               
                               


                

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>









<?php echo $__env->make('cpac/style/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>