<?php echo $__env->make('cpac/style/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('cpac/style/slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">الاعلام</h1>

                    
                   
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            ادارة المحتوى
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>الرقم</th>
                                            <th>عنوان الصفحة</th>
                                            <th></th>
                                         
                                            </tr>
                                    </thead>
                                    <tbody>
                                    
                                        <tr class="odd gradeX">
                                        	
                                            <td>1</td>
                                        	<td>فعاليات المكتب</td>

                                        	<td>
                 <a  class="btn btn-info"   href="" >
                 <i class="glyphicon glyphicon-new-window" aria-hidden="true"></i> عرض </a>
                 <a class="btn btn-warning" href="edit-news">
                 <i class="fa fa-pencil-square-o " aria-hidden="true"></i> تعديل</a>
                                            </td>
                                        </tr>

                                        <tr class="odd gradeX">
                                        	
                                            <td>2</td>
                                        	<td>تبرع للمكتب</td>
                                            
                                        	<td>
                 <a  class="btn btn-info"   href="" >
                 <i class="glyphicon glyphicon-new-window" aria-hidden="true"></i> عرض </a>
                 <a class="btn btn-warning" href="edit-news">
                 <i class="fa fa-pencil-square-o " aria-hidden="true"></i> تعديل</a>
                                            </td>
                                        </tr>
                                        <tr class="odd gradeX">
                                        	
                                            <td>3</td>
                                        	<td>عن المكتب و اعمالة</td>
                                            
                                        	<td>
                 <a  class="btn btn-info"   href="" >
                 <i class="glyphicon glyphicon-new-window" aria-hidden="true"></i> عرض </a>
                 <a class="btn btn-warning" href="edit-media">
                 <i class="fa fa-pencil-square-o " aria-hidden="true"></i> تعديل</a>
                                            </td>
                                        </tr>
                                      
                                      
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>









                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>



<?php echo $__env->make('cpac/style/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>