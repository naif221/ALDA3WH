
    <!-- jQuery Version 1.11.0 -->
    <script src="<?php echo e(('js/jquery-1.11.0.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(('js/bootstrap.min.js')); ?>"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo e(('js/metisMenu/metisMenu.min.js')); ?>"></script>

    <!-- Morris Charts JavaScript -->
    <script src="<?php echo e(('js/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(('js/morris/morris.min.js')); ?>"></script>


    <script src="<?php echo e(('js/jquery/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(('js/bootstrap/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(('js/bootstrap/dataTables.bootstrap.js')); ?>"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo e(('js/sb-admin-2.js')); ?>"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.css" rel="stylesheet">
   
    <script src="<?php echo e(('js/dataTables.responsive.js')); ?>"></script>


<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.js"></script>

    <script>
        $(document).ready(function() {
          $('#dataTables-example').dataTable();
        });
    </script>


<script>
function goBack() {
    window.history.back();
}

function deleted() {
    return confirm('تأكيد الحذف؟')
}

$(document).ready(function() {
  $('.summernote').summernote();
});
</script>



</body>

</html>
