<?php echo $__env->make('cpac/style/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('cpac/style/slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">المكتبة</h1>

                    
                    <a  class="btn btn-primary"   href="new-book" >
                   <i class="fa fa-pencil-square-o" aria-hidden="true"></i> اضافة كتاب جديد </a>


<br>

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            الكتب
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>رقم الكتاب</th>
                                            <th>الباركود</th>
                                            <th>الاسم</th>
                                            <th>المؤلف</th>
                                            <th>اللغة</th>
                                            <th>العدد المتوفر</th>
                                            <th>تعديل/حذف</th>
                                            </tr>
                                    </thead>
                                    <tbody>
                                    
<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="odd gradeX">
                                        	<td><?php echo e($book->id); ?></td>
                                        	<td><?php echo e($book->barcode); ?></td>
                                        	<td><?php echo e($book->name); ?></td>
                                        	<td><?php echo e($book->author->name); ?></td>
                                        	<td><?php echo e($book->language->language); ?></td>
                                            <td>
<?php echo Form::open(['url' => 'edit-in-stock' , 'method' => 'POST']); ?>

                                            
<div class="input-group add-minus">
          <span class="input-group-btn">
              <button type="button" class="btn btn-danger btn-number"  onclick="minus()" >
                <span class="glyphicon glyphicon-minus"></span>
              </button>
          </span>
          
          <input type="text"  class="form-control input-number" name="in_stock"  value="<?php echo e($book->in_stock); ?>" id="count">
          <input type="hidden" type="text" name="id" value="<?php echo e($book->id); ?>">  
          <span class="input-group-btn">
          <script>

 var count = document.getElementById('count').value;

    var countEl = document.getElementById("count");
    function plus(){
        count++;
        countEl.value = count;
    }
    function minus(){
      if (count > 1) {
        count--;
        countEl.value = count;
      }  
    }


</script>
              <button type="button" class="btn btn-success btn-number"  onclick="plus()" >
                  <span class="glyphicon glyphicon-plus"></span>
              </button>
          </span>
          <span class="input-group-btn">
              <button type="button" style="width: 45px; margin-right:5px;" class="btn btn-info btn-number" data-toggle="modal" data-target="#myModal" >
                  <span class="glyphicon glyphicon-floppy-disk"></span>
              </button>
          </span>
      </div>


<!--start confirm save number book in stock	-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <br>
      </div>
      <div class="modal-body">
       هل تريد حفظ التغيرات على العدد المتوفر؟
      <br>
      <br>
        <button type="submit" class="btn btn-primary">حفظ</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">الغاء</button>
       
      </div>
  </div>
</div>
</div>

<?php echo Form::close(); ?>	
</td>
                                <form  method="get" action="<?php echo e(url('edit-book')); ?>">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" type="text" name="id" value="<?php echo e($book->id); ?>">  
                         		<td><center>
                         		<button type="submit" class="btn btn-primary">
                         		<i class="fa fa-pencil-square-o fa-2x" aria-hidden="true">
                         		        </i></button>
                                            </center>
                                </td>
                         		</form> 

               
                                        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>


<style>
.add-minus{
    width: 185px;
    margin: 0px auto;
    
  }
</style>


                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>



<?php echo $__env->make('cpac/style/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>