<?php echo $__env->make('web.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
                <div class="col-lg-12">
                    <h1 class="page-header">المكتبة</h1>

                    <p>

                    تعرض هذه الصفحة جميع الكتب و النشرات المتوفره لدى المكتب مصنفة بجميع اللغات ,<br> حيث يمكنك التوجه للمكتب وطلب الكتاب بعد البحث عنه و التاكد من توفره.

                    </p>
                
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                        <th>الرقم</th>
                                        <th>اسم الكتاب</th>
                                        <th>اللغة</th>
                                        <th>المؤلف</th>
                                            </tr>
                                    </thead>
                                    <tbody>
<?php $__currentLoopData = $Books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo e($book->id); ?></td>
                                            <td><?php echo e($book->name); ?></td>
                                            <td><?php echo e($book->language->language); ?></td>
                                            <td><?php echo e($book->author->name); ?></td>
                                        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            
</div>

        </div>

<?php echo $__env->make('web.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('cpac.style.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>