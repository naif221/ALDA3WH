<?php echo $__env->make('cpac/style/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('cpac/style/slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">الطلبات</h1>

                    
                    <a  class="btn btn-primary"   href="<?php echo e(url('new-request')); ?>" >
                   <i class="fa fa-pencil-square-o" aria-hidden="true"></i> طلب جديد</a>


<br>

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            الطلبات
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>رقم الطلب</th>
                                            <th>الوقت/التاريخ</th>
                                            <th>القسم</th>
                                            <th>نوع الطلب</th>
                                            <th>العنوان</th>
                                            <th>الحالة</th>
                                            <th></th>
                                            </tr>
                                    </thead>
                                    <tbody>
                                    
                                     	<?php if(count($requests) > 0): ?>
                                     		<?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="odd gradeX">
                                        	<td><?php echo e($request->id); ?></td>
                                        	<td><?php echo e($request->created_at); ?></td>
                                        	<td><?php echo e($department_name->department_name); ?></td>
                                        	<?php if(is_null($request->price)): ?>
                                        	<td>طلب عادي</td>
											<?php else: ?> 
                                        	<td>طلب مالي</td>
                                        	<?php endif; ?>
                                        	<td><?php echo e($request->title); ?></td>
                                        	<td><?php echo e($State->title); ?></td>
                                        	<td><a  class="btn btn-info"   href="<?php echo e(url('details-request')); ?>" >
                 <i class="glyphicon glyphicon-new-window" aria-hidden="true"></i> التفاصيل </a></td>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>









                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>



<?php echo $__env->make('cpac/style/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>