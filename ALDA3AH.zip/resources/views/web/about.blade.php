@include('web.navbar')
@include('web.footer')