<div class="col-lg-8">
<div class="panel panel-success">
    <div class="panel-heading">
       اخبار المكتب
    </div>
    <!-- /.panel-heading -->
    <div class="panel-body">
       
         <a href="#">
            <div>
                <strong>John Smith</strong>
                <span class="pull-right text-muted">
                    <em>Yesterday</em>
                </span>
            </div>
            <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a href="#">
            <div>
                <strong>John Smith</strong>
                <span class="pull-right text-muted">
                    <em>Yesterday</em>
                </span>
            </div>
            <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a href="#">
            <div>
                <strong>John Smith</strong>
                <span class="pull-right text-muted">
                    <em>Yesterday</em>
                </span>
            </div>
            <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
        </a>
    </li> <a href="#">
            <div>
                <strong>John Smith</strong>
                <span class="pull-right text-muted">
                    <em>Yesterday</em>
                </span>
            </div>
            <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a href="#">
            <div>
                <strong>John Smith</strong>
                <span class="pull-right text-muted">
                    <em>Yesterday</em>
                </span>
            </div>
            <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a href="#">
            <div>
                <strong>John Smith</strong>
                <span class="pull-right text-muted">
                    <em>Yesterday</em>
                </span>
            </div>
            <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
        </a>
    </li>
    <li class="divider"></li>
    <li>
        <a href="#">
            <div>
                <strong>John Smith</strong>
                <span class="pull-right text-muted">
                    <em>Yesterday</em>
                </span>
            </div>
            <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
        </a>
    </li>
    
    </div>
    <!-- /.panel-body -->
</div>
<!-- /.panel -->
</div>






<div class="col-lg-4">
<div class="panel panel-primary">
    <div class="panel-heading">
       Twitter <b>@afifdh</b>
    </div>
    <!-- /.panel-heading -->
    <div class="panel-body">
        <div class="table-responsive">
              <a class="twitter-timeline" data-height="289" href="https://twitter.com/afifdh">Tweets by afifdh</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>

        </div>
        <!-- /.table-responsive -->
    </div>
    <!-- /.panel-body -->
</div>
</div>



<div class="col-lg-4">
<div class="panel panel-danger">
    <div class="panel-heading">
      YouTube <b>afifdh</b>
    </div>
    <!-- /.panel-heading -->
    <div class="panel-body">
        <li class="divider"></li>
    <li>
        <a href="#">
            <div>
                <strong>John Smith</strong>
                <span class="pull-right text-muted">
                    <em>Yesterday</em>
                </span>
            </div>
            <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
        </a>
    </li>
        <!-- /.table-responsive -->
    </div>
    <!-- /.panel-body -->
</div>
</div>

<div class="col-lg-4">
<div class="panel panel-default">
    <div class="panel-heading">
     <b>المكتبة</b>قم بحجز و استلم الكتب الموجودة لدى المكتب
    </div>
    <!-- /.panel-heading -->
    <div class="panel-body">
        <div class="table-responsive">
        </div>
        <!-- /.table-responsive -->
    </div>
    <!-- /.panel-body -->
</div>
</div>

<div class="col-lg-4">
<div class="panel panel-default">
    <div class="panel-heading">
      فعاليات المكتب
    </div>
    <!-- /.panel-heading -->
    <div class="panel-body">
        <div class="table-responsive">
        </div>
        <!-- /.table-responsive -->
    </div>
    <!-- /.panel-body -->
</div>
</div>

<div class="col-lg-4">
<div class="panel panel-default">
    <div class="panel-heading">
      تبرع للمكتب
    </div>
    <!-- /.panel-heading -->
    <div class="panel-body">
        <div class="table-responsive">
        </div>
        <!-- /.table-responsive -->
    </div>
    <!-- /.panel-body -->
</div>
</div>












