<style>
html {
  position: relative;
  min-height: 100%;
}

body {
  margin-bottom: 150px;
}

.footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 150px;
  background-color: #111;
  text-align: center;
}

.asas{
  margin-top: 50px;
  color: #fff;
  width: 100%;
}

.fa-twitter {
    color: #4099FF;
}

.fa-facebook {
    color: #3B5998;
}

.fa-youtube-play {
    color: #e52d27;
}

.fa-rss {
    color: #FF6600;
}

.fa-vine {
    color: #00a478;
}

.fa-flickr {
    color: #ff0084;
}

.fa-twitch {
    color: #6441A5;
}

.fa-linkedin {
    color: #007bb6;
}

.fa {
    opacity: 0.7;
    transition: 1s;
    -webkit-transition: 1s;
}

.fa:hover{
    opacity: 1;
    transition: 1s;
    -webkit-transition: 1s;
</style>

<script>
function deleted() {
    confirm("تأكيد الحذف!");
}
</script>

</div>
				</div>
				
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <div class="footer">
      <div class="asas">
	         <h4></h4>
              <a href=''><i class="fa fa-facebook fa-2x fa-fw"></i></a>
              <a href=''><i class="fa fa-twitter fa-2x fa-fw"></i></a>
              <a href=''><i class="fa fa-linkedin fa-2x fa-fw"></i></a>
            </span>
			<h6>&copy;  <?php echo date('Y'); ?></h6>
			
      </div>
    </div>
			
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</body>
	</html>